from controller import Supervisor, Keyboard
import math

supervisor = Supervisor()
timestep = int(supervisor.getBasicTimeStep())

keyboard = Keyboard()
keyboard.enable(timestep)

print("Controlador supervisor iniciado.")
nombre_objeto = "RoCaja"
#nombre_tabero = "Tablero"
tablero = [0,0,0]

nodo = supervisor.getFromDef(nombre_objeto)
#nodo2 = supervisor.getFromDef(nombre_tablero)

if nodo is None:
    print("❌ No se encontró un nodo con DEF")
else:
    posicion = nodo.getField("translation")
    orientacion = nodo.getField("rotation")
    
#if nodo2 is None:
#    print("❌ No se encontró un nodo con DEF")
#else:
#    posicion2 = nodo2.getField("translation")
#    orientacion2 = nodo2.getField("rotation")

delta = 0.001
delta_r = math.pi / 180

nueva_rotacion = [0, 1, 0, math.pi / 24]
orientacion.setSFRotation(nueva_rotacion)

while supervisor.step(timestep) != -1:
    key = keyboard.getKey()
    if key != -1:
        if key == ord('Q'):
            break
        
        if key == Keyboard.UP:
            print("La caja esta subiendo y girando...") 
            delta = delta + 0.01
        if key == Keyboard.DOWN:
            print("La caja esta bajando y girando...") 
            delta = delta - 0.01
        if key == Keyboard.LEFT:
            print("La caja gira a la izquierda...")
            delta_r = delta_r - 0.01
        if key == Keyboard.RIGHT:
            print("La caja gira a la derecha...")
            delta_r = delta_r + 0.01
            
               
    posicion_actual = posicion.getSFVec3f()
    posicion_actual[2] = posicion_actual[2] + delta
    
    orientacion_actual = orientacion.getSFRotation()
    orientacion_actual[3] = orientacion_actual[3] + delta_r
    
    posicion.setSFVec3f(posicion_actual)
    orientacion.setSFRotation(orientacion_actual)
    
    a = posicion_actual[0] - tablero[0]
    b = posicion_actual[1] - tablero[1]
    c = posicion_actual[2] - tablero[2]
    distancia = math.sqrt(a**2 + b**2 + c**2)
    
    print("La distancia es:", distancia)
